import Header from "./components/Header/index.js";
import Head from "./components/Hero/HeadSection.js";
import Carosoul from "./components/Slider/Slider.js";
import Brands from "./components/Brand/Brand.js";
import CardSection from "./components/cardSection/CardSection"
import Talks from "./components/Talks/Talks.js";
import Footer from "./components/Footer/Footer.js";

import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../node_modules/bootstrap/dist/js/bootstrap.bundle";
function App() {
  return (

    <div>
      <Header />  
      <Head />  
      <Carosoul/>
      <Brands/>
      <CardSection/>
      <Talks/>
      <Footer/>
    </div>

  );
}

export default App;
