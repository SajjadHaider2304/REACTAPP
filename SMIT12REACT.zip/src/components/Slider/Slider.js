import Slide from "../../assests/slide.png";
import Slide1 from "../../assests/slide1.png";
import Slide2 from "../../assests/slide2.png";
import Slide3 from "../../assests/slide3.png";
import Slide4 from "../../assests/slide4.png";





function Carosoul() {
    return(


        <div className="container-fluid rounded   bg-dark mt-5  ">
        <div className="row">
            <div className="col-lg-12 col-sm-12 mt-5 mb-5">
                <div id="carouselExampleControls" className="carousel slide" data-ride="carousel">
                    <div className="carousel-inner">
                        <div className="carousel-item active  text-center">
                            <img className=" mr-5 brand-Imge " src={Slide} alt="First slide" />
                            <img className=" mr-5 brand-Imge " src={Slide2} alt="First slide" />
                            <img className=" mr-5 brand-Imge  " src={Slide3} alt="First slide " />
                            <img className=" mr-5 brand-Imge " src={Slide1} alt="First slide" />
                            
                        </div>
                        <div className="carousel-item  ">
                            <img className=" mr-5 brand-Imge " src={Slide3} alt="First slide" />
                            <img className=" mr-5 brand-Imge " src={Slide2} alt="First slide" />
                            <img className=" mr-5 brand-Imge " src={Slide} alt="First slide" />
                            <img className=" mr-5 brand-Imge " src={Slide4} alt="First slide" />
                           
                        </div>

                    </div>
                    <div className="carousel-item    ">
                        <img className=" mr-5  brand-Imge" src={Slide} alt="First slide" />
                        <img className=" mr-5 brand-Imge " src={Slide2} alt="First slide" />
                        <img className=" mr-5 brand-Imge " src={Slide3} alt="First slide" />
                        <img className=" mr-5 brand-Imge " src={Slide1} alt="First slide" />
                    </div>

                </div>
            </div>
            <a className="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                <span className="carousel-control-prev-icon" aria-hidden="true"></span>
                <span className="sr-only">Previous</span>
            </a>
            <a className="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                <span className="carousel-control-next-icon" aria-hidden="true"></span>
                <span className="sr-only">Next</span>
            </a>
        </div>
    </div>

    );
    
}
export default Carosoul;