import Icon1 from "../../assests/icon 01.png";
import Icon2 from "../../assests/icon 02.png";
import Icon3 from "../../assests/icon 03.png";


function Brands() {
    return(
        <div className="container  mt-5 mb-5">
        <h1 className="text-center textheading mb-3">What Can We Help You Find </h1>
        <div className="row mainRow">
            <div className="col-lg-3 col-sm-12  cardFlex">
                <img src={Icon1} alt=""/>
                <h3 className="textheading">Buy Homes</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellendus, nobis? Nesciunt accusantium
                    rem provident. Est nostrum expedita odit autem omnis?</p>

            </div>
            <div className="col-lg-3 col-sm-12   cardFlex">

                <img src={Icon2} alt=""/>
                <h3 className="textheading">Rent Homes</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellendus, nobis? Nesciunt accusantium
                    rem provident. Est nostrum expedita odit autem omnis?</p>
            </div>
            <div className="col-lg-3 col-sm-12 cardFlex">
                <img src={Icon3} alt=""/>
                <h3 className="textheading">See Nieghborhoods</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellendus, nobis? Nesciunt accusantium
                    rem provident. Est nostrum expedita odit autem omnis?</p>
            </div>
        </div>
    </div>

    );
    
}
export default Brands;