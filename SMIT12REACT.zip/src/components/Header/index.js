


function Header(){
    return(

        <div className="container-fluid">
        <div className="row">


            <div className="col-12 ">
                <nav className="navbar navbar-expand-lg navbar-light Hover-nav">
                    <div className="container">
                        <div className="d-flex">
                            <a className="navbar-brand d-flex mx-5 nameweb textheading" href="#"> <i>bisnik</i> </a>

                        </div>
                        <div>
                            <button className="navbar-toggler" type="button" data-toggle="collapse"
                                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                aria-expanded="false" aria-label="Toggle navigation">
                                <span className="navbar-toggler-icon"></span>
                            </button>
                            <div className="collapse navbar-collapse mr-5 customcss" id="navbarSupportedContent">
                                <ul className="navbar-nav pr-4  me-auto mb-2 mb-lg-0">
                                    <li className="nav-item">
                                        <a className="nav-link navBar active textheading" aria-current="page"
                                            href="#">Home</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link navBar textheading" href="#">About us</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link navBar textheading" href="#">Features</a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link navBar textheading" href="#">Contact</a>
                                    </li>
                                    <form>

                                        <button className="btn btn-outline-info mx-2 btn-css" type="submit">Sign
                                            in</button>
                                        <button className="btn btn-info text-white mx-2 btn-css" type="submit">Sign
                                            Up</button>
                                    </form>

                                </ul>

                            </div>
                        </div>
                    </div>
                </nav>
            </div>



        </div>
    </div>

    );
    
   
    
    
    
 
}
export default Header;