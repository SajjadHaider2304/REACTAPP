import React from "react";
import Image from "../../assests/Iamge.png"


function Head() {
    return (
 
            <div className="container flex-head ">
                <div className="row heading12">
                    <div className="col-lg-6 col-sm-12 mt-4">
                        <h1 className="textheading">Search for <br /> Homes in your Neighbergood</h1>
                        <p className="mt-2 textheading">Online State Agency, the moderen way to sell your own Home.
                            You can use griffenresiddential to market your property</p>

                        <div className="dropButton">
                            <div>
                                <select className="form-control" name="" id="">
                                    <option className="form-control" value="">Address</option>
                                    <option className="form-control" value="">534 furry Road</option>
                                    <option className="form-control" value="">534 furry Road</option>
                                    <option className="form-control" value="">534 furry Road</option>
                                </select>
                            </div>
                            <div>
                                <select className="form-control" name="" id="">
                                    <option className="form-control" value="">City</option>
                                    <option className="form-control" value="">EL PASO, TEXAS</option>
                                    <option className="form-control" value="">PEl,Ex New York</option>
                                </select>
                            </div>
                            <button className="btn btn-info btn-css">Search</button>

                        </div>
                    </div>
                    <div className="col-lg-6 col-sm-12  mt-4  picbgnav ">
                        <div className="cardname">
                            <img className="image1" src={Image} alt="" />
                            <h4 className="text-danger ml-5">$99,8980</h4>
                            <h5>Newport</h5>

                        </div>


                    </div>
                </div>
            </div>
     

    );
}
export default Head;