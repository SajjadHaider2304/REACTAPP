

function Talks() {
    return (
        <section>
            <div className="container mb-4">
                <div class="row">
                    <div className="col-lg-6 col-sm-12 textheading">
                        <h2 className="textheading text-center mb-4">Our Latest Trending Property</h2>

                    </div>
                    <div className="col-lg-6 col-sm-12 d-flex justify-content-around">
                        <form action="">
                            <select className="form-control" name="" id="">
                                <option value="">Property Type</option>

                            </select>
                        </form>
                        <button className="btn btn-sm btn-info text-white">See All Property</button>
                    </div>

                </div>
            </div>

            <div class="container-fluid talks">
                <div class="container  ">
                    <div class="row">
                        <div class="col-lg-6 text-center">
                            <h1 class="text-white  my-3">Talk to Redfin Agernt</h1>
                            <p class="text-white  mb-5 ">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ipsam cupiditate facere ex, nihil rerum
                                molestias quidem accusantium aspernatur dignissimos sit quaerat eius minus?</p>
                        </div>
                        <div className="col-lg-2">

                        </div>
                        <div class="col-lg-4 text-center">
                            <p className="text-white mt-5">
                                Where are you searching Homes?
                            </p>
                            <div class="input-group mb-3">
                                <input type="text" className="form-control" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2"/>
                                    <div class="input-group-append bg-info">
                                        <span class="input-group-text bg-info" id="basic-addon2">Search</span>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );

}
export default Talks;
