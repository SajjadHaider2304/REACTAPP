


function Footer() {
    return (
        <div class="container my-5">
            <div class="row ">
                <div class="col-lg-3 col-sm-6">
                    <h2 class="textheading">Populars Search</h2>
                    <a href="#">Apartment for Rent</a><br/>
                    <a href="#">Apartment Low To High</a><br/>
                    <a href="#">Offices for Buy</a><br/>
                    <a href="#">Offices for Rent</a><br/>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <h2 class="textheading">About Us</h2>
                    <a href="#">Our Story</a> <br/>
                    <a href="#">Team Members</a><br/>
                    <a href="#">Careers</a><br/>
                    <a href="#">Contact us</a><br/>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <h2 class="textheading">Quick Links </h2>
                    <a href="#">Terms of Uses</a><br/>
                    <a href="#">Privacy Policy</a><br/>
                    <a href="#">Contact Support</a><br/>
                    <a href="#">FAQs</a>
                </div>
                <div class="col-lg-3 col-sm-6">
                    <h2 class="textheading">Links</h2>
                    <a href="#">Help Center</a><br/>
                    <a href="#">Load Support </a><br/>
                    <a href="#">Management </a><br/>
                    <a href="#">Privacy Policy </a><br/>
                </div>
            </div>
        </div>

    );

}
export default Footer;