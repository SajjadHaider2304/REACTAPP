import React from 'react';
import Image1 from "../../assests/image (1).png"
import Image2 from "../../assests/image (2).png"
import Image3 from "../../assests/image (3).png"
import Image4 from "../../assests/image (4).png"
import Heart from "../../assests/Heart.png"
import Bed from "../../assests/bed.png"
import Bath from '../../assests/bath.png'






 function CardSection() {
  return (
      <div className="container mt-5 mb-5">
            <div className="row justify-content-around">
                <div className="col-lg-5 col-md-8 ">
                       <div className="row carditem">
                        <div className="col-6">
                            <img className="image-fluid" src={Image1}  alt=""/>
                        </div>
                        <div className="col-6 ">
                            <div className="icontext">
                                <h3 className="text-info">$259,000</h3>
                                <img className="image-fluid imags" src={Heart} alt=""/>    
                            </div>
                            <h5 >Case Alda</h5>
                            <p className="text-secondary">Co Rd Tribune Tribune</p>

                            <div className="bathbad">
                                <img className="imagesbad" src={Bed} alt=""/>
                                <h6>2 Beds</h6>
                                <img className="imagesbad" src={Bath} alt=""/>
                                <h6>2 Bath</h6>
                            </div>
                            <button className="btn btn-outline-info mt-2  ">View Details</button>
                        </div>
                       </div>
                </div>
                <div className="col-lg-5 col-md-8 ">
                    <div className="row mt-2 carditem ">
                        <div className="col-6">
                            <img className="image-fluid" src={Image2} alt=""/>
                        </div>
                        <div className="col-6 ">
                            <div className="icontext">
                                <h3 className="text-info">$259,000</h3>
                                <img className="image-fluid imags" src={Heart} alt=""/>    
                            </div>
                            <h5 >Case Alda</h5>
                            <p className="text-secondary">Co Rd Tribune Tribune</p>

                            <div className="bathbad">
                                <img className="imagesbad" src={Bed} alt=""/>
                                <h6>2 Beds</h6>
                                <img className="imagesbad" src={Bath} alt=""/>
                                <h6>2 Bath</h6>
                            </div>
                            <button className="btn btn-outline-info mt-2  ">View Details</button>
                        </div>
                       </div>
                    
                </div>
            </div>
            <div className="row justify-content-around mt-5">
                <div className="col-lg-5 col-md-8 ">
                       <div className="row carditem">
                        <div className="col-6">
                            <img className="image-fluid" src={Image3} alt=""/>
                        </div>
                        <div className="col-6 ">
                            <div className="icontext">
                                <h3 className="text-info">$259,000</h3>
                                <img className="image-fluid imags" src={Heart} alt=""/>    
                            </div>
                            <h5 >Case Alda</h5>
                            <p className="text-secondary">Co Rd Tribune Tribune</p>

                            <div className="bathbad">
                                <img className="imagesbad" src={Bed} alt=""/>
                                <h6>2 Beds</h6>
                                <img className="imagesbad" src={Bath} alt=""/>
                                <h6>2 Bath</h6>
                            </div>
                            <button className="btn btn-outline-info mt-2  ">View Details</button>
                        </div>
                       </div>
                </div>
                <div className="col-lg-5 col-md-8 ">
                    <div className="row carditem">
                        <div className="col-6">
                            <img className="image-fluid" src={Image4} alt=""/>
                        </div>
                        <div className="col-6 ">
                            <div className="icontext">
                                <h3 className="text-info">$259,000</h3>
                                <img className="image-fluid imags" src={Heart} alt=""/>    
                            </div>
                            <h5 >Case Alda</h5>
                            <p className="text-secondary">Co Rd Tribune Tribune</p>

                            <div className="bathbad">
                                <img className="imagesbad" src={Bed} alt=""/>
                                <h6>2 Beds</h6>
                                <img className="imagesbad" src={Bath} alt=""/>
                                <h6>2 Bath</h6>
                            </div>
                            <button className="btn btn-outline-info mt-2  ">View Details</button>
                        </div>
                       </div>
                    
                </div>
            </div>
        </div>
  );
}
export default CardSection;

